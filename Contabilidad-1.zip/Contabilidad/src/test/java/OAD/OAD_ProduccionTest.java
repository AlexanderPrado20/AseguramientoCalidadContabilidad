package OAD;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;

public class OAD_ProduccionTest {

    OAD_Produccion oad = new OAD_Produccion();

    // --- TC-01: Camino Feliz (Cálculos matemáticos) ---
    @Test
    public void testCalcularCosto_CaminoFeliz() {
        try {
            int cantidad = 1;
            double[] resultados = oad.calcularCosto(cantidad);
            assertNotNull(resultados);
            assertTrue(resultados[0] >= 0, "El costo total debe ser mayor o igual a 0");
        } catch (Exception e) {
            System.out.println("Test omitido/fallido por entorno (BD no disponible): " + e.getMessage());
        }
    }

    // --- TC-02: Camino de Excepción (Entrada inválida) ---
    @Test
    public void testObtenerDetalleCosto_CaminoExcepcion() {
        try {
            // Probamos con 0, comportamiento ante entradas atípicas
            ArrayList<Object[]> lista = oad.obtenerDetalleCosto(0);
            assertNotNull(lista, "La lista no debe ser nula aunque no haya datos");
        } catch (Exception e) {
            System.out.println("Test omitido/fallido por entorno (BD no disponible): " + e.getMessage());
        }
    }

    // --- TC-03: Camino de Excepción (Datos fuera de límites) ---
    @Test
    public void testGuardarOrden_ValoresNegativos() {
        try {
            // Simulamos el intento de guardar una orden con cantidad negativa
            int id = oad.guardarOrden("Test", -5, 0.0, 0.0);
            
            // Esperamos que el sistema devuelva 0 (fallo controlado) al recibir valores negativos
            assertEquals(0, id, "El sistema debe rechazar órdenes con cantidad negativa");
        } catch (Exception e) {
            System.out.println("Test omitido/fallido por entorno (BD no disponible): " + e.getMessage());
        }
    }
}