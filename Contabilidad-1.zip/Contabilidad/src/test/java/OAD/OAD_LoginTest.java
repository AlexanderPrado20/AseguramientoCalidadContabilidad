package OAD;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OAD_LoginTest {

    OAD_Login login = new OAD_Login();

    @Test
    public void testValidarUsuario_CaminoFeliz() {
        try {
            boolean resultado = login.validarUsuario("admin", "1234");
            // Evalúa que la consulta devuelva un booleano válido
            assertTrue(resultado == true || resultado == false);
        } catch (Exception e) {
            System.out.println("Test omitido por entorno (BD no disponible): " + e.getMessage());
        }
    }

    @Test
    public void testValidarUsuario_CredencialesIncorrectas() {
        try {
            boolean resultado = login.validarUsuario("usuario_falso", "wrongpass");
            assertFalse(resultado, "El sistema debe denegar el acceso a credenciales inexistentes");
        } catch (Exception e) {
            System.out.println("Test omitido por entorno (BD no disponible): " + e.getMessage());
        }
    }

    @Test
    public void testValidarUsuario_CamposVacios() {
        try {
            boolean resultado = login.validarUsuario("", "");
            assertFalse(resultado, "El sistema debe rechazar inicios de sesión con campos vacíos");
        } catch (Exception e) {
            System.out.println("Test omitido por entorno (BD no disponible): " + e.getMessage());
        }
    }
}
