package OAD;

import java.sql.*;
import java.util.ArrayList;
import Conexion.Conexion;

public class OAD_Inventario {

    public ArrayList<Object[]> obtenerInventario() {

        ArrayList<Object[]> lista = new ArrayList<>();

        try {
            Connection con = Conexion.getConexion();

            String sql = "SELECT * FROM inventario";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[5];

                fila[0] = rs.getInt("id");
                fila[1] = rs.getString("nombre");
                fila[2] = rs.getString("unidad");
                fila[3] = rs.getDouble("cantidad");
                fila[4] = rs.getDouble("costo_unitario");

                lista.add(fila);
            }

        } catch (Exception e) {
            System.out.println("Error inventario: " + e.getMessage());
        }

        return lista;
    }
    public void actualizarCosto(int id, double nuevoCosto) {

    try {
        Connection con = Conexion.getConexion();

        String sql = "UPDATE inventario SET costo_unitario = ? WHERE id = ?";
        PreparedStatement ps = con.prepareStatement(sql);

        ps.setDouble(1, nuevoCosto);
        ps.setInt(2, id);

        ps.executeUpdate();

    } catch (Exception e) {
        System.out.println("Error al actualizar costo: " + e.getMessage());
    }
}
    public void agregarStock(int id, double cantidadAgregar) {

    try {
        Connection con = Conexion.getConexion();

        String sql = "UPDATE inventario SET cantidad = cantidad + ? WHERE id = ?";
        PreparedStatement ps = con.prepareStatement(sql);

        ps.setDouble(1, cantidadAgregar);
        ps.setInt(2, id);

        ps.executeUpdate();

    } catch (Exception e) {
        System.out.println("Error al agregar stock: " + e.getMessage());
    }
}
}