package OAD;

import java.sql.*;
import Conexion.Conexion;
import java.util.ArrayList;

public class OAD_Produccion {

    public double[] calcularCosto(int cantidad) {

        double costoMateriaPrima = 0;
        double costoManoObra = 0;
        double costoIndirecto = 0;
        double costoTotal = 0;
        double costoUnitario = 0;

        try {
            Connection con = Conexion.getConexion();

            // ? OBTENER COSTO DE MATERIA PRIMA
            String sql = "SELECT i.costo_unitario, r.cantidad_usada " +
                         "FROM receta r " +
                         "JOIN inventario i ON r.id_ingrediente = i.id " +
                         "WHERE r.id_producto = 1";

            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                double costo = rs.getDouble("costo_unitario");
                double cantidadUsada = rs.getDouble("cantidad_usada");

                costoMateriaPrima += (cantidadUsada * costo * cantidad);
            }

            // ? MANO DE OBRA
            double manoObraPorUnidad = 10; // puedes cambiarlo
            costoManoObra = manoObraPorUnidad * cantidad;

            // ? COSTOS INDIRECTOS
            double indirectoPorUnidad = 5; // ejemplo
            costoIndirecto = indirectoPorUnidad * cantidad;

            // ? COSTO TOTAL
            costoTotal = costoMateriaPrima + costoManoObra + costoIndirecto;

            // ? COSTO UNITARIO
            costoUnitario = costoTotal / cantidad;

            // ? ACTUALIZAR INVENTARIO
            //String update = "UPDATE inventario i " +
                            
            //"JOIN receta r ON i.id = r.id_ingrediente " +
                            
            //"SET i.cantidad = i.cantidad - (r.cantidad_usada * ?) " +
                            //"WHERE r.id_producto = 1";

            //PreparedStatement psUpdate = con.prepareStatement(update);
            //psUpdate.setInt(1, cantidad);
            //psUpdate.executeUpdate();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        // ? REGRESAMOS TODO
        return new double[]{
            costoTotal,
            costoUnitario,
            costoMateriaPrima,
            costoManoObra,
            costoIndirecto
        };
    }
    public ArrayList<Object[]> obtenerDetalleCosto(int cantidad) {

    ArrayList<Object[]> lista = new ArrayList<>();

    try {

        Connection con = Conexion.getConexion();

        String sql =
                "SELECT i.nombre, r.cantidad_usada, i.costo_unitario " +
                "FROM receta r " +
                "JOIN inventario i ON r.id_ingrediente = i.id " +
                "WHERE r.id_producto = 1";

        PreparedStatement ps = con.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            String nombre = rs.getString("nombre");

            double cantidadUsada =
                    rs.getDouble("cantidad_usada") * cantidad;

            double costo =
                    rs.getDouble("costo_unitario") * cantidadUsada;

            lista.add(new Object[]{
                nombre,
                cantidadUsada,
                costo
            });
        }

    } catch (Exception e) {

        System.out.println(e.getMessage());
    }

    return lista;
}

    public int guardarOrden(String cliente, int cantidad, double total, double unitario) {

    int idGenerado = 0;

    try {
        Connection con = Conexion.getConexion();

        String sql = "INSERT INTO orden (cliente, fecha, cantidad, costo_total, costo_unitario) VALUES (?, CURDATE(), ?, ?, ?)";

        PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        ps.setString(1, cliente);
        ps.setInt(2, cantidad);
        ps.setDouble(3, total);
        ps.setDouble(4, unitario);

        ps.executeUpdate();

        ResultSet rs = ps.getGeneratedKeys();

        if (rs.next()) {
            idGenerado = rs.getInt(1);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return idGenerado;
}
public ArrayList<Object[]> obtenerOrdenes() {

    ArrayList<Object[]> lista = new ArrayList<>();

    try {
        Connection con = Conexion.getConexion();

        String sql = "SELECT id, cliente, fecha, cantidad, costo_total, costo_unitario FROM orden";

        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            Object[] fila = new Object[6];

            fila[0] = rs.getInt("id");
            fila[1] = rs.getString("cliente");
            fila[2] = rs.getDate("fecha");
            fila[3] = rs.getInt("cantidad");
            fila[4] = rs.getDouble("costo_total");
            fila[5] = rs.getDouble("costo_unitario");

            lista.add(fila);
        }

    } catch (Exception e) {
        System.out.println("Error al obtener órdenes: " + e.getMessage());
    }

    return lista;
}
public int obtenerTotalOrdenes() {

    int total = 0;

    try {

        Connection con = Conexion.getConexion();

        String sql = "SELECT COUNT(*) FROM orden";

        PreparedStatement ps = con.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            total = rs.getInt(1);
        }

    } catch (Exception e) {
        System.out.println("Error gráfica: " + e.getMessage());
    }

    return total;
}
public ArrayList<String> obtenerClientes() {

    ArrayList<String> lista = new ArrayList<>();

    try {

        Connection con = Conexion.getConexion();

        String sql = "SELECT nombre FROM clientes";

        PreparedStatement ps = con.prepareStatement(sql);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {

            lista.add(rs.getString("nombre"));
        }

    } catch (Exception e) {

        System.out.println("Error clientes: " + e.getMessage());
    }

    return lista;
}
public double[] obtenerDatosGrafica() {

    double costo = 42.2;
    double venta = 0;

    try {

        Connection con = Conexion.getConexion();

        String sql =
                "SELECT precio_venta " +
                "FROM productos " +
                "WHERE id = 1";

        PreparedStatement ps =
                con.prepareStatement(sql);

        ResultSet rs =
                ps.executeQuery();

        if (rs.next()) {

            venta = rs.getDouble("precio_venta");
        }

    } catch (Exception e) {

        System.out.println(
                "Error gráfica pastel: "
                + e.getMessage()
        );
    }

    double ganancia = venta - costo;

    return new double[] {
        costo,
        ganancia
    };
}
public ArrayList<Object[]> obtenerOrdenesPorDia() {

    ArrayList<Object[]> lista = new ArrayList<>();

    try {
        Connection con = Conexion.getConexion();

        String sql = "SELECT DATE(fecha) AS dia, COUNT(*) AS total " +
                     "FROM orden " +
                     "GROUP BY DATE(fecha) " +
                     "ORDER BY dia";

        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Object[] fila = new Object[2];
            fila[0] = rs.getString("dia");
            fila[1] = rs.getInt("total");
            lista.add(fila);
        }

    } catch (Exception e) {
        System.out.println("Error barras: " + e.getMessage());
    }

    return lista;
}
public void descontarInventario(int cantidad) {

    try {

        Connection con = Conexion.getConexion();

        String sql =
                "UPDATE inventario i " +
                "JOIN receta r ON i.id = r.id_ingrediente " +
                "SET i.cantidad = i.cantidad - (r.cantidad_usada * ?) " +
                "WHERE r.id_producto = 1";

        PreparedStatement ps =
                con.prepareStatement(sql);

        ps.setInt(1, cantidad);

        ps.executeUpdate();

    } catch (Exception e) {

        System.out.println(
                "Error descontando inventario: "
                + e.getMessage()
        );
    }
}
public void agregarCliente(
        String nombre,
        String telefono
) {

    try {

        Connection con =
                Conexion.getConexion();

        String sql =
                "INSERT INTO clientes(nombre, telefono) " +
                "VALUES (?, ?)";

        PreparedStatement ps =
                con.prepareStatement(sql);

        ps.setString(1, nombre);

        ps.setString(2, telefono);

        ps.executeUpdate();

    } catch (Exception e) {

        System.out.println(
                e.getMessage()
        );
    }
}
public String obtenerMejorCliente() {

    String resultado = "Sin datos";

    try {

        Connection con =
                Conexion.getConexion();

        String sql =
    "SELECT cliente, COUNT(*) total " +
    "FROM orden " +
    "WHERE cliente IS NOT NULL " +
    "AND cliente <> '' " +
    "AND cliente <> '1' " +
    "GROUP BY cliente " +
    "ORDER BY total DESC " +
    "LIMIT 1";

        PreparedStatement ps =
                con.prepareStatement(sql);

        ResultSet rs =
                ps.executeQuery();

        if (rs.next()) {

            resultado =
                    rs.getString("cliente")
                    + " (" +
                    rs.getInt("total")
                    + " órdenes)";
        }

    } catch (Exception e) {

        System.out.println(
                e.getMessage()
        );
    }

    return resultado;
}
}