package OAD;

import java.sql.*;
import Conexion.Conexion;

public class OAD_Login {

    public boolean validarUsuario(String usuario, String contraseña) {

        boolean valido = false;

        try {
            Connection con = Conexion.getConexion();

            String sql = "SELECT * FROM usuarios WHERE usuario = ? AND contraseña = ?";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, usuario);
            ps.setString(2, contraseña);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                valido = true;
            }

        } catch (Exception e) {
            System.out.println("Error login: " + e.getMessage());
        }

        return valido;
    }
}