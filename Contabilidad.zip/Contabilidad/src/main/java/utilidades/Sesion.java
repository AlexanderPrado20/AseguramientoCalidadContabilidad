
package utilidades;

/**
 *
 * @author capit
 */
public class Sesion {
 

    public static String usuario = "";
}
    

