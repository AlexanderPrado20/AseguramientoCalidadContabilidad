package utilidades;


import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;

import java.time.LocalDate;

import java.util.ArrayList;

import OAD.OAD_Produccion;

public class GenerarPDF {

    public static void generarPDF(

            String cliente,
            int cantidad,
            double costoTotal,
            double costoUnitario,
            double ventaTotal,
            double ganancia,
            double margen
    ) {

        try {

            String nombreArchivo = "HojaCostos.pdf";

            Document doc = new Document();

            PdfWriter.getInstance(
                    doc,
                    new FileOutputStream(nombreArchivo)
            );

            doc.open();

            // 🔥 LOGO UV
            try {
String rutaLogo =
            GenerarPDF.class
            .getResource("C:\\Users\\capit\\Downloads\\equipo.png")
            .toExternalForm();

    Image logoUV = Image.getInstance(rutaLogo);

    logoUV.scaleToFit(80, 80);

    logoUV.setAlignment(Element.ALIGN_CENTER);

    doc.add(logoUV);

           

            } catch (Exception e) {

                System.out.println("No se encontró el logo UV");
            }

            // 🔥 TITULO
            Paragraph titulo = new Paragraph(
                    "UNIVERSIDAD VERACRUZANA\n"
                    + "TV AZTECA\n"
                    + "HOJA DE COSTOS\n\n",
                    FontFactory.getFont(
                            FontFactory.HELVETICA_BOLD,
                            18
                    )
            );

            titulo.setAlignment(Element.ALIGN_CENTER);

            doc.add(titulo);

            // 🔥 FECHA
            LocalDate fecha = LocalDate.now();

            doc.add(new Paragraph("Cliente: " + cliente));

            doc.add(new Paragraph("Fecha: " + fecha));

            doc.add(new Paragraph("Cantidad: " + cantidad));

            doc.add(new Paragraph("\n"));

            // 🔥 COSTOS
            doc.add(new Paragraph(
                    "Costo total: $" + costoTotal
            ));

            doc.add(new Paragraph(
                    "Costo unitario: $" + costoUnitario
                   
            ));
            if(margen >= 50){

    doc.add(new Paragraph(
            "Rentabilidad: ALTA"
    ));

}else if(margen >= 30){

    doc.add(new Paragraph(
            "Rentabilidad: MEDIA"
    ));

}else{

    doc.add(new Paragraph(
            "Rentabilidad: BAJA"
    ));
}

            doc.add(new Paragraph("\n"));

            // 🔥 ANALISIS
            doc.add(new Paragraph(
                    "--- ANALISIS FINANCIERO ---"
            ));

            doc.add(new Paragraph(
                    "Venta total: $" + ventaTotal
            ));

            doc.add(new Paragraph(
                    "Ganancia: $" + ganancia
            ));

            doc.add(new Paragraph(
                    "Margen: " + margen + "%"
            ));

            doc.add(new Paragraph("\n"));

            // 🔥 TABLA
            OAD_Produccion oad =
                    new OAD_Produccion();

            ArrayList<Object[]> datos =
                    oad.obtenerDetalleCosto(cantidad);

            PdfPTable tabla = new PdfPTable(3);

            tabla.setWidthPercentage(100);

            tabla.addCell("Ingrediente");
            tabla.addCell("Cantidad");
            tabla.addCell("Costo");

            for (Object[] fila : datos) {

                tabla.addCell(fila[0].toString());

                tabla.addCell(fila[1].toString());

                tabla.addCell("$" + fila[2].toString());
            }

            doc.add(tabla);
            

// 🔥 PIE DE PÁGINA

doc.add(new Paragraph("\n"));

doc.add(new Paragraph(
        "Documento generado automáticamente por el Sistema de Costos de Producción."
));

doc.add(new Paragraph(
        "Universidad Veracruzana - Licenciatura en Sistemas Computacionales Administrativos"
));

doc.add(new Paragraph(
        "Proyecto Final - Contabilidad Gerencial"
));

doc.close();

            doc.close();

            // 🔥 ABRIR PDF
            File archivo = new File(nombreArchivo);

            if (Desktop.isDesktopSupported()) {

                Desktop.getDesktop().open(archivo);
            }

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}
