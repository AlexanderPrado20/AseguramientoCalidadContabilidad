
package vistas;

import OAD.OAD_Produccion;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author capit
 */
public class FrmGraficas extends javax.swing.JFrame {

 public FrmGraficas() {
    initComponents();
    mostrarGraficaBarras();
    mostrarGraficaPastel();
}

public void mostrarGraficaBarras() {

    OAD_Produccion oad = new OAD_Produccion();

    int total = oad.obtenerTotalOrdenes();

    DefaultCategoryDataset datos = new DefaultCategoryDataset();

    datos.setValue(total, "Órdenes", "Registradas");

    JFreeChart grafica = ChartFactory.createBarChart(
            "Total de Órdenes",
            "Tipo",
            "Cantidad",
            datos
    );

    ChartPanel panel = new ChartPanel(grafica);

    panel.setPreferredSize(new java.awt.Dimension(400, 300));

    panelBarras.setLayout(new java.awt.BorderLayout());

    panelBarras.removeAll();

    panelBarras.add(panel);

    panelBarras.validate();
}
public void mostrarGraficaPastel() {

    DefaultPieDataset datos = new DefaultPieDataset();

    datos.setValue("Materia Prima", 50);
    datos.setValue("Gastos Indirectos", 20);
    datos.setValue("Mano de Obra", 20);
    datos.setValue("Ganancia", 10);

    JFreeChart grafica = ChartFactory.createPieChart(
            "Costo del Producto",
            datos,
            true,
            true,
            false
    );

    ChartPanel panel = new ChartPanel(grafica);

    panel.setPreferredSize(new java.awt.Dimension(400, 300));

    panelPastel.setLayout(new java.awt.BorderLayout());

    panelPastel.removeAll();

    panelPastel.add(panel);

    panelPastel.validate();
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelPastel = new javax.swing.JPanel();
        panelBarras = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelPastel.setBackground(new java.awt.Color(204, 255, 204));

        javax.swing.GroupLayout panelPastelLayout = new javax.swing.GroupLayout(panelPastel);
        panelPastel.setLayout(panelPastelLayout);
        panelPastelLayout.setHorizontalGroup(
            panelPastelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 264, Short.MAX_VALUE)
        );
        panelPastelLayout.setVerticalGroup(
            panelPastelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 329, Short.MAX_VALUE)
        );

        panelBarras.setBackground(new java.awt.Color(204, 255, 153));

        javax.swing.GroupLayout panelBarrasLayout = new javax.swing.GroupLayout(panelBarras);
        panelBarras.setLayout(panelBarrasLayout);
        panelBarrasLayout.setHorizontalGroup(
            panelBarrasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 264, Short.MAX_VALUE)
        );
        panelBarrasLayout.setVerticalGroup(
            panelBarrasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 284, Short.MAX_VALUE)
        );

        jButton1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelPastel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(panelBarras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(jButton1)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelPastel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(panelBarras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
FrmMenuPrincipal menu = new FrmMenuPrincipal();

menu.setLocationRelativeTo(null);

menu.setVisible(true);

this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmGraficas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmGraficas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmGraficas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmGraficas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmGraficas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel panelBarras;
    private javax.swing.JPanel panelPastel;
    // End of variables declaration//GEN-END:variables
}
